<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
<link rel="stylesheet" href="adminlogin.css">

    <title>Login</title>

  </head>
  <body>

  <h1 style="color: white">Customizable Movie Database</h1>
  <br>
  <h3>Admin</h3>
  <br>
  <br>
  <br>
  <br>
<form class="box" action="./admin_login.php" method="post" >
  <h1>Log In</h1>
  <input type="text" name="name" placeholder="Admin Name">
  <input type="password" name="password" placeholder="Password">
  <input type="submit" name="Login" value="Login">
</form>

  </body>
</html>
