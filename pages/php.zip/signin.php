<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
<link rel="stylesheet" href="signin.css">

    <title>Login</title>

  </head>
  <body>

  <h1 style="color: white" >Customizable Movie Database</h1>
  <br>
  <br>
  <br>
  <br>
  <br>
<form class="box" action="login.php" method="post" >
  <h1>Log In</h1>
  <input type="text" name="email" placeholder="E-Mail">
  <input type="password" name="password" placeholder="Password">
  <input type="submit" name="Login" value="Login">
  <a href="Registration.php">Don't You Have An Account. Click Here</a>
</form>

  </body>
</html>
